#!/bin/bash

PATH=/usr/bin:$PATH python3 build_index.py
