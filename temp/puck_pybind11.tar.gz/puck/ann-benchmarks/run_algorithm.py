from benchmark.runner import run_from_cmdline

run_from_cmdline()
