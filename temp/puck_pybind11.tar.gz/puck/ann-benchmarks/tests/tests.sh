#!/bin/bash

# You should run this script from the repo top-level directory

PYTHONPATH="." python tests/recall_tests.py

